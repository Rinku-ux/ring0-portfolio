import type { ReactNode } from "react";
import type { Metadata } from "next";
import "./globals.css";
import { Nav } from "@/components/Nav";
import { HardwareFrame } from "@/components/HardwareFrame";

export const metadata: Metadata = {
  title: "Ring0 // Industrial Firmware & Creative Engineering",
  description: "Next-generation web games, high-performance tools, and interactive digital artifacts.",
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <div className="tech-bg" />
        <div className="optical-vignette" />
        <HardwareFrame />
        <div className="shell">
          <Nav />
          <main>{children}</main>
        </div>
      </body>
    </html>
  );
}
