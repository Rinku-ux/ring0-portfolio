"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Magnetic } from "@/components/Magnetic";
import { playClick } from "@/lib/audio";

const LINKS = [
  { href: "/work", label: "SPECIMENS" },
  { href: "/transmissions", label: "LOGS" },
  { href: "/about", label: "OPERATOR" },
] as const;

export function Nav() {
  const pathname = usePathname();

  return (
    <header className="top">
      <Magnetic strength={0.25} radius={80}>
        <Link
          className="brand mono"
          href="/"
          onClick={() => playClick()}
          title="Return to System Core"
        >
          <span className="brand-dot" />
          <span className="brand-title">RING0</span>
          <span className="brand-hint">CORE::SYS</span>
        </Link>
      </Magnetic>

      <nav className="primary mono" aria-label="primary">
        {LINKS.map((link) => {
          const current =
            link.href === "/work"
              ? pathname.startsWith("/work")
              : pathname === link.href;

          return (
            <Magnetic key={link.href} strength={0.3} radius={70}>
              <Link
                href={link.href}
                aria-current={current ? "page" : undefined}
                onClick={() => playClick()}
              >
                <span className="nav-prefix">{current ? "●" : "○"}</span>
                {link.label}
              </Link>
            </Magnetic>
          );
        })}
      </nav>
    </header>
  );
}
