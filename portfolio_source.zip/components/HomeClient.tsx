"use client";

import React, { useState } from "react";
import Link from "next/link";
import type { Project } from "@/lib/types";
import { ProjectCard } from "@/components/ProjectCard";
import { InspectorPanel } from "@/components/InspectorPanel";
import { Magnetic } from "@/components/Magnetic";
import { playClick } from "@/lib/audio";

interface HomeClientProps {
  projects: Project[];
}

export function HomeClient({ projects }: HomeClientProps) {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const featured = projects.find((p) => p.featured) ?? projects[0];

  const handleInspect = (project: Project) => {
    setSelectedProject(project);
  };

  const handleCloseInspector = () => {
    setSelectedProject(null);
  };

  return (
    <>
      {/* Firmware Lab Hero */}
      <section className="hero">
        <div>
          <div className="hero-telemetry mono">
            <span className="telemetry-indicator pulse-cyan" />
            <span>OPERATIONAL // LAB_FIRMWARE_V26</span>
          </div>
          <h1>
            CREATIVE <span className="accent-text">ENGINEERING</span>
            <br />& DIGITAL ARTIFACTS
          </h1>
          <p className="hero-sub">
            Frontend craft, interactive WebGL/3D graphics, and experimental browser utilities.
            Designed with millimeter-level precision and high-performance execution.
          </p>

          <div style={{ marginTop: 24, display: "flex", gap: 12 }}>
            {featured && (
              <Magnetic strength={0.3} radius={90}>
                <button
                  type="button"
                  className="btn-inspect mono"
                  onClick={() => {
                    playClick();
                    handleInspect(featured);
                  }}
                >
                  <span>⚡ INSPECT FEATURED [{featured.title.toUpperCase()}]</span>
                </button>
              </Magnetic>
            )}
            <Magnetic strength={0.25} radius={80}>
              <Link
                href="/about"
                className="btn-secondary mono"
                style={{ height: "100%" }}
                onClick={() => playClick()}
              >
                <span>OPERATOR SPEC ↗</span>
              </Link>
            </Magnetic>
          </div>
        </div>

        {/* Real-time System Telemetry Stats */}
        <div className="hero-stats mono">
          <div className="stat-box">
            <div className="stat-num">{String(projects.length).padStart(2, "0")}</div>
            <div className="stat-label">MODULES LOADED</div>
          </div>
          <div className="stat-box">
            <div className="stat-num">0.08<span style={{ fontSize: 13, color: "var(--muted)" }}>s</span></div>
            <div className="stat-label">HYDRATION TIME</div>
          </div>
          <div className="stat-box">
            <div className="stat-num">100<span style={{ fontSize: 13, color: "var(--muted)" }}>%</span></div>
            <div className="stat-label">INTEGRITY CHECK</div>
          </div>
          <div className="stat-box">
            <div className="stat-num">V26</div>
            <div className="stat-label">SYSTEM BUILD</div>
          </div>
        </div>
      </section>

      {/* Featured Primary Specimen */}
      {featured && (
        <section style={{ marginBottom: 48 }}>
          <div className="section-header mono">
            <h2 className="section-label">
              <span>◆</span> PRIMARY SPECIMEN
            </h2>
            <span className="section-tag">FEATURED MODULE</span>
          </div>

          <div
            className="featured-module"
            onClick={() => handleInspect(featured)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                handleInspect(featured);
              }
            }}
          >
            <img src={featured.cover} alt={`${featured.title} cover preview`} />
            <div className="featured-overlay">
              <div className="featured-badge-row mono">
                <span className="badge-tag">{featured.kind.toUpperCase()}</span>
                <span className="text-muted">RELEASE: {featured.year}</span>
                <span className={`status-pill status-${featured.status}`}>
                  ● {featured.status.toUpperCase()}
                </span>
              </div>
              <h2>{featured.title}</h2>
              <p className="summary">{featured.summary}</p>
              <div className="featured-footer mono">
                <div className="stack-tags">
                  {featured.stack.map((tech) => (
                    <span key={tech} className="stack-tag-tiny">
                      {tech}
                    </span>
                  ))}
                </div>
                <span className="btn-inspect">
                  OPEN TELEMETRY ↗
                </span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Project Inventory Grid */}
      <section>
        <div className="section-header mono">
          <h2 className="section-label">
            <span>◆</span> LOADED MODULES ({projects.length})
          </h2>
          <span className="section-tag">CLICK TO INSPECT</span>
        </div>

        <div className="inventory">
          {projects.map((project) => (
            <ProjectCard
              key={project.slug}
              project={project}
              onInspect={handleInspect}
            />
          ))}
        </div>
      </section>

      {/* Inspector Slide-out Panel */}
      <InspectorPanel
        project={selectedProject}
        onClose={handleCloseInspector}
      />

      {/* System Footer Telemetry */}
      <footer className="foot mono">
        <div>
          <span>FIRMWARE: RING0_CORE // SYSTEM ARCHITECTURE</span>
        </div>
        <div>
          <span>ALL WORK AUTHORED BY OPERATOR</span>
        </div>
      </footer>
    </>
  );
}
