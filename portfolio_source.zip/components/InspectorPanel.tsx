"use client";

import React, { useEffect } from "react";
import Link from "next/link";
import type { Project } from "@/lib/types";
import { playOpen, playClose, playClick } from "@/lib/audio";

interface InspectorPanelProps {
  project: Project | null;
  onClose: () => void;
}

export function InspectorPanel({ project, onClose }: InspectorPanelProps) {
  useEffect(() => {
    if (project) {
      playOpen();
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          playClose();
          onClose();
        }
      };
      window.addEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "hidden";
      return () => {
        window.removeEventListener("keydown", handleKeyDown);
        document.body.style.overflow = "";
      };
    }
  }, [project, onClose]);

  if (!project) return null;

  const handleClose = () => {
    playClose();
    onClose();
  };

  return (
    <div className="inspector-backdrop" onClick={handleClose}>
      <aside
        className="inspector-panel"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-label={`Project Inspector: ${project.title}`}
      >
        {/* Panel Header */}
        <div className="inspector-header">
          <div className="inspector-telemetry">
            <span className="telemetry-indicator pulse-cyan" />
            <span className="mono">INSPECTOR // {project.slug.toUpperCase()}</span>
          </div>
          <button
            type="button"
            className="inspector-close-btn mono"
            onClick={handleClose}
            aria-label="Close Inspector [ESC]"
            title="Close [ESC]"
          >
            ✕ [ESC]
          </button>
        </div>

        {/* Panel Body */}
        <div className="inspector-content">
          {/* Cover Preview with HUD overlay */}
          <div className="inspector-media hud-module">
            <img src={project.cover} alt={project.title} className="inspector-img" />
            <div className="inspector-media-badge mono">
              <span>RES: 1080P</span>
              <span>STATE: {project.status.toUpperCase()}</span>
            </div>
          </div>

          {/* Project Title & Metadata Grid */}
          <div className="inspector-section">
            <div className="inspector-meta-row mono">
              <span className="badge-tag">{project.kind.toUpperCase()}</span>
              <span className="text-muted">RELEASE: {project.year}</span>
              <span className={`status-pill status-${project.status}`}>
                ● {project.status.toUpperCase()}
              </span>
            </div>
            <h2 className="inspector-title">{project.title}</h2>
            <p className="inspector-summary">{project.summary}</p>
          </div>

          {/* Action Links */}
          <div className="inspector-actions">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noreferrer"
                className="btn-primary mono"
                onClick={() => playClick()}
              >
                <span>{project.playable ? "⚡ EXECUTE RUNTIME" : "⚡ LAUNCH SERVICE"}</span>
              </a>
            )}
            {project.repoUrl && (
              <a
                href={project.repoUrl}
                target="_blank"
                rel="noreferrer"
                className="btn-secondary mono"
                onClick={() => playClick()}
              >
                <span>SOURCE REPO</span>
              </a>
            )}
            <Link
              href={`/work/${project.slug}`}
              className="btn-secondary mono"
              onClick={() => {
                playClick();
                onClose();
              }}
            >
              <span>READ ARCHIVE ↗</span>
            </Link>
          </div>

          {/* Tech Stack Specs */}
          <div className="inspector-section">
            <h3 className="section-title mono">TECHNICAL STACK</h3>
            <div className="stack-grid">
              {project.stack.map((item) => (
                <div key={item} className="stack-item mono">
                  <span className="stack-bullet">◆</span>
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* System Telemetry & Logs */}
          <div className="inspector-section">
            <h3 className="section-title mono">SYSTEM TELEMETRY</h3>
            <div className="telemetry-log mono">
              <div className="log-line">
                <span className="text-muted">[0.00ms]</span> TARGET: {project.slug}
              </div>
              <div className="log-line">
                <span className="text-muted">[0.12ms]</span> ARCHITECTURE: NEXTJS / MDX / REACT19
              </div>
              <div className="log-line">
                <span className="text-muted">[0.25ms]</span> INTEGRITY: VERIFIED_PASS
              </div>
              <div className="log-line text-cyan">
                <span className="text-muted">[0.33ms]</span> READY FOR INTERACTION
              </div>
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
}
