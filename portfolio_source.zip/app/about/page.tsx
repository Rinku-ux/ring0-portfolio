export default function AboutPage() {
  return (
    <div className="writeup">
      {/* Header Dossier */}
      <div className="spec-header">
        <div className="mono" style={{ fontSize: 12, color: "var(--accent)", marginBottom: 8 }}>
          <span>DOSSIER // PILOT & CREATOR SPECIFICATION</span>
        </div>
        <h1>OPERATOR PROFILE</h1>
        <p className="mono" style={{ color: "var(--muted)", margin: 0 }}>
          CODENAME: RING0 // CLEARANCE: LEVEL-4 // SPECIALIZATION: FRONTEND & WEBGL
        </p>
      </div>

      {/* Module 1: Introduction */}
      <section className="spec-module">
        <h2>
          <span>◆</span> INTRODUCTION & DIRECTIVE
        </h2>
        <p>
          Thank you for visiting my portfolio. I am a frontend developer and creative engineer
          crafting friction-free in-browser games and practical web utilities as personal projects.
        </p>
        <p>
          Driven by the engineering directive of <em>&ldquo;turning ideas into working prototypes with extreme velocity,&rdquo;</em> my work spans from high-performance 3D browser games to activity-sharing web platforms and lightweight workflow automations using Google Apps Script.
        </p>
      </section>

      {/* Module 2: Core Engineering Domains */}
      <section className="spec-module">
        <h2>
          <span>◆</span> PRIMARY DOMAINS
        </h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 16 }}>
          <div style={{ padding: 20, border: "1px solid var(--line)", background: "rgba(0, 0, 0, 0.4)", borderRadius: 4 }}>
            <h3 className="mono" style={{ color: "var(--accent)", margin: "0 0 10px", fontSize: 14 }}>
              ⚡ 01 // WEB GAMES & GRAPHICS
            </h3>
            <p style={{ margin: 0, fontSize: 13, color: "var(--text)", lineHeight: 1.6 }}>
              3D action and interactive mini-games built with Three.js, Canvas 2D, and WebGL. Engineered for instant loading and zero-installation direct play in modern browsers.
            </p>
          </div>
          <div style={{ padding: 20, border: "1px solid var(--line)", background: "rgba(0, 0, 0, 0.4)", borderRadius: 4 }}>
            <h3 className="mono" style={{ color: "var(--accent)", margin: "0 0 10px", fontSize: 14 }}>
              🛠 02 // WEB TOOLS & PLATFORMS
            </h3>
            <p style={{ margin: 0, fontSize: 13, color: "var(--text)", lineHeight: 1.6 }}>
              High-utility web platforms built with React, Next.js, and Google Apps Script, including fitness/running telemetry loggers and automated productivity scripts.
            </p>
          </div>
        </div>
      </section>

      {/* Module 3: Protocol Matrix (Tech Stack) */}
      <section className="spec-module">
        <h2>
          <span>◆</span> PROTOCOL MATRIX & SKILLSET
        </h2>
        <div className="inventory-items mono">
          <span className="item">TypeScript</span>
          <span className="item">JavaScript (ESNext)</span>
          <span className="item">React 19 / Next.js</span>
          <span className="item">HTML5 / Modern CSS</span>
          <span className="item">Three.js / WebGL</span>
          <span className="item">Canvas 2D API</span>
          <span className="item">Google Apps Script</span>
          <span className="item">Node.js</span>
          <span className="item">Git / GitHub</span>
          <span className="item">Vercel Deployment</span>
        </div>
      </section>

      {/* Module 4: Verification Telemetry */}
      <section className="spec-module" style={{ borderLeft: "3px solid var(--amber)" }}>
        <h2 style={{ color: "var(--amber)" }}>
          <span>▲</span> SYSTEM CONTACT & TRANSMISSION
        </h2>
        <p style={{ fontSize: 13, color: "var(--muted)", margin: "0 0 16px" }}>
          Inquiries, collaboration propositions, and code feedback are welcomed via GitHub and social channels.
        </p>
        <div style={{ display: "flex", gap: 12 }}>
          <a
            href="https://github.com/Rinku-ux"
            target="_blank"
            rel="noreferrer"
            className="btn-secondary mono"
            style={{ fontSize: 12 }}
          >
            <span>GITHUB PROTOCOL ↗</span>
          </a>
        </div>
      </section>
    </div>
  );
}
