import { getProjects } from "@/lib/projects";
import { HomeClient } from "@/components/HomeClient";

export default function HomePage() {
  const projects = getProjects();

  return <HomeClient projects={projects} />;
}
