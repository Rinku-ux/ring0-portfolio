"use client";

import React, { useState } from "react";
import Link from "next/link";
import type { Project, Kind } from "@/lib/types";
import { KINDS } from "@/lib/types";
import { ProjectCard } from "@/components/ProjectCard";
import { InspectorPanel } from "@/components/InspectorPanel";
import { playClick } from "@/lib/audio";

interface WorkClientProps {
  projects: Project[];
  selectedKind?: Kind;
}

export function WorkClient({ projects, selectedKind }: WorkClientProps) {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const handleInspect = (project: Project) => {
    setSelectedProject(project);
  };

  const handleCloseInspector = () => {
    setSelectedProject(null);
  };

  return (
    <div className="writeup" style={{ maxWidth: 1200 }}>
      <div className="spec-header">
        <div className="mono" style={{ fontSize: 12, color: "var(--accent)", marginBottom: 6 }}>
          <span>ARCHIVE // SPECIMENS DIRECTORY</span>
        </div>
        <h1>SPECIMENS CATALOG</h1>
        <p className="mono" style={{ color: "var(--muted)", margin: 0 }}>
          Index of experimental games, interactive tools, and web prototypes.
        </p>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 32, flexWrap: "wrap" }}>
        <Link
          className={`btn-secondary mono ${!selectedKind ? "active" : ""}`}
          style={{
            padding: "6px 14px",
            borderColor: !selectedKind ? "var(--accent)" : undefined,
            color: !selectedKind ? "var(--accent)" : undefined,
            background: !selectedKind ? "rgba(0, 240, 255, 0.1)" : undefined,
          }}
          href="/work"
          onClick={() => playClick()}
        >
          <span>ALL SPECIMENS ({projects.length})</span>
        </Link>
        {KINDS.map((item) => {
          const isActive = selectedKind === item;
          return (
            <Link
              key={item}
              className={`btn-secondary mono ${isActive ? "active" : ""}`}
              style={{
                padding: "6px 14px",
                borderColor: isActive ? "var(--accent)" : undefined,
                color: isActive ? "var(--accent)" : undefined,
                background: isActive ? "rgba(0, 240, 255, 0.1)" : undefined,
              }}
              href={`/work?kind=${item}`}
              onClick={() => playClick()}
            >
              <span>{item.toUpperCase()}</span>
            </Link>
          );
        })}
      </div>

      <div className="inventory">
        {projects.map((project) => (
          <ProjectCard
            key={project.slug}
            project={project}
            onInspect={handleInspect}
          />
        ))}
      </div>

      <InspectorPanel
        project={selectedProject}
        onClose={handleCloseInspector}
      />
    </div>
  );
}
