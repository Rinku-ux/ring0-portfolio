"use client";

import React from "react";
import type { Project } from "@/lib/types";
import { playHover, playClick } from "@/lib/audio";

interface ProjectCardProps {
  project: Project;
  onInspect?: (project: Project) => void;
}

export function ProjectCard({ project, onInspect }: ProjectCardProps) {
  const handleClick = (e: React.MouseEvent) => {
    if (onInspect) {
      e.preventDefault();
      playClick();
      onInspect(project);
    }
  };

  return (
    <article
      className="slot"
      onClick={handleClick}
      onMouseEnter={() => playHover()}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleClick(e as unknown as React.MouseEvent);
        }
      }}
    >
      <div className="slot-img-wrap">
        <img src={project.cover} alt={`${project.title} module preview`} />
      </div>

      <div className="slot-body">
        <div className="slot-header mono">
          <span className="badge-tag">{project.kind.toUpperCase()}</span>
          <span className="text-muted">{project.year}</span>
        </div>

        <h3>{project.title}</h3>
        <p className="slot-summary">{project.summary}</p>

        <div className="slot-footer mono">
          <div className="stack-tags">
            {project.stack.slice(0, 3).map((tech) => (
              <span key={tech} className="stack-tag-tiny">
                {tech}
              </span>
            ))}
          </div>
          <span className="inspect-pill">
            INSPECT <span>↗</span>
          </span>
        </div>
      </div>
    </article>
  );
}
