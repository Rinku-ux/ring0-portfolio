"use client";

import React, { useState, useEffect } from "react";
import { toggleAudio, isAudioEnabled, playClick } from "@/lib/audio";

export function HardwareFrame() {
  const [coords, setCoords] = useState({ x: 0, y: 0 });
  const [timeStr, setTimeStr] = useState("");
  const [audioOn, setAudioOn] = useState(false);

  useEffect(() => {
    setAudioOn(isAudioEnabled());

    const updateClock = () => {
      const now = new Date();
      const h = String(now.getHours()).padStart(2, "0");
      const m = String(now.getMinutes()).padStart(2, "0");
      const s = String(now.getSeconds()).padStart(2, "0");
      const ms = String(Math.floor(now.getMilliseconds() / 10)).padStart(2, "0");
      setTimeStr(`${h}:${m}:${s}.${ms}`);
    };

    updateClock();
    const interval = setInterval(updateClock, 33); // ~30fps clock update

    const handleMouseMove = (e: MouseEvent) => {
      setCoords({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => {
      clearInterval(interval);
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  const handleAudioToggle = () => {
    const newState = toggleAudio();
    setAudioOn(newState);
  };

  return (
    <div className="hardware-frame" aria-hidden="true">
      {/* Corner Reticles */}
      <div className="reticle reticle-tl" />
      <div className="reticle reticle-tr" />
      <div className="reticle reticle-bl" />
      <div className="reticle reticle-br" />

      {/* Top Telemetry Bar */}
      <div className="telemetry-bar telemetry-top">
        <div className="telemetry-item">
          <span className="telemetry-indicator pulse-cyan" />
          <span className="telemetry-label">SYS_STATE</span>
          <span className="telemetry-val">ONLINE [V.26]</span>
        </div>
        <div className="telemetry-item desktop-only">
          <span className="telemetry-label">KERNEL</span>
          <span className="telemetry-val">RING0::CORE</span>
        </div>
        <div className="telemetry-item telemetry-right">
          <button
            type="button"
            className={`audio-toggle-btn ${audioOn ? "active" : ""}`}
            onClick={handleAudioToggle}
            title="Toggle Synthesizer SFX"
            aria-label="Toggle UI Sound Effects"
          >
            <span className="sound-icon">{audioOn ? "🔊" : "🔇"}</span>
            <span className="sound-text">SFX: {audioOn ? "ON" : "OFF"}</span>
          </button>
          <div className="telemetry-clock mono">{timeStr || "00:00:00.00"}</div>
        </div>
      </div>

      {/* Bottom Telemetry Bar */}
      <div className="telemetry-bar telemetry-bottom">
        <div className="telemetry-item">
          <span className="telemetry-label">LOC</span>
          <span className="telemetry-val mono">
            X:{String(coords.x).padStart(4, "0")} Y:{String(coords.y).padStart(4, "0")}
          </span>
        </div>
        <div className="telemetry-item desktop-only">
          <span className="telemetry-label">DISPLAY</span>
          <span className="telemetry-val">OPTICAL_FIRMWARE</span>
        </div>
        <div className="telemetry-item telemetry-right desktop-only">
          <span className="telemetry-label">STATUS</span>
          <span className="telemetry-val text-amber">ALL SYSTEMS NORMAL</span>
        </div>
      </div>
    </div>
  );
}
