import { getProjects } from "@/lib/projects";
import { KINDS, type Kind } from "@/lib/types";
import { WorkClient } from "@/components/WorkClient";

function isKind(value: string | undefined): value is Kind {
  return Boolean(value && (KINDS as readonly string[]).includes(value));
}

export default async function WorkPage({
  searchParams,
}: {
  searchParams: Promise<{ kind?: string }>;
}) {
  const { kind } = await searchParams;
  const selected = isKind(kind) ? kind : undefined;
  const allProjects = getProjects();
  const filtered = allProjects.filter((project) =>
    selected ? project.kind === selected : true,
  );

  return <WorkClient projects={filtered} selectedKind={selected} />;
}
