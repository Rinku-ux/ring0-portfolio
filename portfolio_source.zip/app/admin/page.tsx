"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { playClick, playOpen, playClose } from "@/lib/audio";
import type { Transmission } from "@/lib/transmissions";

const STORAGE_KEY = "ring0_admin_token";

export default function AdminPage() {
  const [password, setPassword] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [loading, setLoading] = useState(false);

  // Content input
  const [content, setContent] = useState("");
  const [tag, setTag] = useState("LOG");
  const [transmissions, setTransmissions] = useState<Transmission[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load auth state from session
  useEffect(() => {
    const saved = sessionStorage.getItem(STORAGE_KEY);
    if (saved) {
      setPassword(saved);
      setIsAuthenticated(true);
      fetchTransmissions();
    }
  }, []);

  const fetchTransmissions = async () => {
    try {
      const res = await fetch("/api/transmissions");
      if (res.ok) {
        const data = await res.json();
        setTransmissions(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    if (password === "ring01102") {
      playOpen();
      setIsAuthenticated(true);
      sessionStorage.setItem(STORAGE_KEY, password);
      fetchTransmissions();
    } else {
      playClose();
      setErrorMsg("ACCESS DENIED // INVALID SECURITY KEY");
    }
  };

  const handleLogout = () => {
    playClose();
    sessionStorage.removeItem(STORAGE_KEY);
    setIsAuthenticated(false);
    setPassword("");
    setErrorMsg("");
  };

  const handlePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    setIsSubmitting(true);
    playClick();

    try {
      const res = await fetch("/api/transmissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, content, tag }),
      });

      if (res.ok) {
        setContent("");
        playOpen();
        await fetchTransmissions();
      } else {
        const err = await res.json();
        alert(`Failed to post: ${err.error}`);
      }
    } catch (e) {
      alert("Network error occurred.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Confirm transmission deletion?")) return;

    playClick();
    try {
      const res = await fetch("/api/transmissions", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, id }),
      });

      if (res.ok) {
        playClose();
        setTransmissions((prev) => prev.filter((tx) => tx.id !== id));
      } else {
        alert("Failed to delete.");
      }
    } catch (e) {
      alert("Network error.");
    }
  };

  return (
    <div className="writeup" style={{ maxWidth: 860 }}>
      {/* Header */}
      <div className="spec-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 16 }}>
        <div>
          <div className="mono" style={{ fontSize: 12, color: "var(--accent)", marginBottom: 6 }}>
            <span>SECURITY LEVEL-4 // RESTRICTED ACCESS</span>
          </div>
          <h1>OPERATOR CONSOLE</h1>
          <p className="mono" style={{ color: "var(--muted)", margin: 0 }}>
            Broadcast dispatch & transmission telemetry management.
          </p>
        </div>

        <div>
          <Link
            href="/transmissions"
            className="btn-secondary mono"
            style={{ fontSize: 11, padding: "6px 14px" }}
          >
            <span>PUBLIC FEED ↗</span>
          </Link>
        </div>
      </div>

      {!isAuthenticated ? (
        /* Password Gate Form */
        <div className="spec-module" style={{ maxWidth: 440, margin: "40px auto", textAlign: "center" }}>
          <div className="mono" style={{ fontSize: 11, color: "var(--amber)", marginBottom: 12 }}>
            <span>▲ AUTHENTICATION REQUIRED</span>
          </div>
          <h2 style={{ justifyContent: "center", marginBottom: 20 }}>KEYCARD VERIFICATION</h2>

          <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter Operator Security Key..."
                className="admin-input mono"
                autoFocus
                required
              />
            </div>

            {errorMsg && (
              <div className="mono text-amber" style={{ fontSize: 11 }}>
                {errorMsg}
              </div>
            )}

            <button type="submit" className="btn-primary mono" style={{ width: "100%" }}>
              <span>AUTHENTICATE & UNLOCK</span>
            </button>
          </form>
        </div>
      ) : (
        /* Authenticated Dashboard */
        <div style={{ display: "flex", flexDirection: "column", gap: 32 }}>
          {/* Post Creation Module */}
          <div className="spec-module" style={{ borderLeft: "3px solid var(--accent)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <h2 style={{ margin: 0 }}>
                <span>⚡</span> DISPATCH NEW TRANSMISSION
              </h2>
              <button
                type="button"
                onClick={handleLogout}
                className="btn-secondary mono"
                style={{ fontSize: 11, padding: "3px 10px", color: "var(--muted)" }}
              >
                LOGOUT
              </button>
            </div>

            <form onSubmit={handlePost} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                <span className="mono" style={{ fontSize: 12, color: "var(--muted)" }}>TAG:</span>
                {["LOG", "SYSTEM", "DEV", "IDEA"].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTag(t)}
                    className={`btn-secondary mono ${tag === t ? "active" : ""}`}
                    style={{
                      fontSize: 11,
                      padding: "4px 10px",
                      borderColor: tag === t ? "var(--accent)" : undefined,
                      color: tag === t ? "var(--accent)" : undefined,
                      background: tag === t ? "rgba(0, 240, 255, 0.1)" : undefined,
                    }}
                  >
                    {t}
                  </button>
                ))}
              </div>

              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Type your transmission / thought / status update..."
                className="admin-textarea"
                rows={4}
                required
              />

              <div style={{ display: "flex", justifyContent: "flex-end" }}>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-primary mono"
                  style={{ minWidth: 180 }}
                >
                  <span>{isSubmitting ? "TRANSMITTING..." : "⚡ BROADCAST LOG"}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Existing Transmissions List */}
          <div>
            <div className="section-header mono">
              <h2 className="section-label">
                <span>◆</span> ARCHIVED TRANSMISSIONS ({transmissions.length})
              </h2>
              <span className="section-tag">MANAGEMENT CONSOLE</span>
            </div>

            <div className="transmissions-feed">
              {transmissions.map((tx) => (
                <article key={tx.id} className="transmission-card">
                  <div className="transmission-header mono">
                    <div className="transmission-meta">
                      <span className="badge-tag">{tx.tag || "LOG"}</span>
                      <span className="text-muted">{tx.timestamp}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDelete(tx.id)}
                      className="btn-delete mono"
                      title="Delete transmission"
                    >
                      DELETE [✕]
                    </button>
                  </div>
                  <div className="transmission-body">
                    <p style={{ margin: 0, whiteSpace: "pre-wrap", lineHeight: 1.6 }}>
                      {tx.content}
                    </p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
