import React from "react";
import Link from "next/link";
import { getTransmissions } from "@/lib/transmissions";

export const dynamic = "force-dynamic";

export default function TransmissionsPage() {
  const transmissions = getTransmissions();

  const formatDate = (iso: string) => {
    try {
      const d = new Date(iso);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const date = String(d.getDate()).padStart(2, "0");
      const h = String(d.getHours()).padStart(2, "0");
      const min = String(d.getMinutes()).padStart(2, "0");
      return `${y}.${m}.${date} ${h}:${min}`;
    } catch {
      return iso;
    }
  };

  return (
    <div className="writeup" style={{ maxWidth: 860 }}>
      {/* Feed Header */}
      <div className="spec-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 16 }}>
        <div>
          <div className="mono" style={{ fontSize: 12, color: "var(--accent)", marginBottom: 6 }}>
            <span>BROADCAST // OPERATOR CHATTER & LOGS</span>
          </div>
          <h1>TRANSMISSIONS</h1>
          <p className="mono" style={{ color: "var(--muted)", margin: 0 }}>
            Real-time thought streams, project notes, and system status updates.
          </p>
        </div>

        <div style={{ alignSelf: "flex-end" }}>
          <Link
            href="/admin"
            className="btn-secondary mono"
            style={{ fontSize: 11, padding: "5px 12px" }}
          >
            <span>OPERATOR LOGIN ↗</span>
          </Link>
        </div>
      </div>

      {/* Transmissions Feed */}
      <div className="transmissions-feed">
        {transmissions.length === 0 ? (
          <div className="spec-module mono text-muted" style={{ textAlign: "center", padding: 32 }}>
            NO TRANSMISSIONS LOGGED YET.
          </div>
        ) : (
          transmissions.map((tx) => (
            <article key={tx.id} className="transmission-card">
              <div className="transmission-header mono">
                <div className="transmission-meta">
                  <span className="telemetry-indicator pulse-cyan" />
                  <span className="badge-tag">{tx.tag || "LOG"}</span>
                  <span className="text-muted">{formatDate(tx.timestamp)}</span>
                </div>
                <span className="transmission-id text-muted">ID::{tx.id.replace("tx-", "")}</span>
              </div>

              <div className="transmission-body">
                <p style={{ margin: 0, whiteSpace: "pre-wrap", lineHeight: 1.7 }}>
                  {tx.content}
                </p>
              </div>
            </article>
          ))
        )}
      </div>

      {/* System Footer */}
      <footer className="foot mono">
        <div>
          <span>STREAM STATUS: BROADCASTING // TOTAL: {transmissions.length}</span>
        </div>
        <div>
          <span>SECURE END-TO-END</span>
        </div>
      </footer>
    </div>
  );
}
