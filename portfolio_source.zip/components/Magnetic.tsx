"use client";

import React, { useRef, useState, useEffect } from "react";
import { playHover, playClick } from "@/lib/audio";

interface MagneticProps {
  children: React.ReactNode;
  strength?: number; // Attraction strength (default: 0.3)
  radius?: number; // Active radius in pixels (default: 100)
  className?: string;
  style?: React.CSSProperties;
  onClick?: (e: React.MouseEvent) => void;
  sound?: boolean;
}

export function Magnetic({
  children,
  strength = 0.35,
  radius = 120,
  className = "",
  style = {},
  onClick,
  sound = true,
}: MagneticProps) {
  const elementRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const isHovered = useRef(false);

  useEffect(() => {
    // Only enable magnetic hover on desktop pointers
    const isTouch = window.matchMedia("(pointer: coarse)").matches;
    if (isTouch) return;

    const handleMouseMove = (e: MouseEvent) => {
      const el = elementRef.current;
      if (!el) return;

      const rect = el.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const distX = e.clientX - centerX;
      const distY = e.clientY - centerY;
      const distance = Math.hypot(distX, distY);

      if (distance < radius) {
        if (!isHovered.current) {
          isHovered.current = true;
          if (sound) playHover();
        }
        // Magnetic pull toward cursor
        const pullX = distX * strength;
        const pullY = distY * strength;
        setPos({ x: pullX, y: pullY });
      } else {
        if (isHovered.current) {
          isHovered.current = false;
        }
        setPos({ x: 0, y: 0 });
      }
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, [strength, radius, sound]);

  const handleClick = (e: React.MouseEvent) => {
    if (sound) playClick();
    if (onClick) onClick(e);
  };

  return (
    <div
      ref={elementRef}
      className={`magnetic-wrap ${className}`}
      onClick={handleClick}
      style={{
        ...style,
        transform: `translate3d(${pos.x}px, ${pos.y}px, 0)`,
        transition:
          pos.x === 0 && pos.y === 0
            ? "transform 0.55s cubic-bezier(0.175, 0.885, 0.32, 1.275)"
            : "transform 0.12s ease-out",
        display: "inline-block",
      }}
    >
      {children}
    </div>
  );
}
